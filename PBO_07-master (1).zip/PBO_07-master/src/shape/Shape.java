package shape;

public abstract class Shape {
    public abstract double area();
    public abstract String getType();
}
